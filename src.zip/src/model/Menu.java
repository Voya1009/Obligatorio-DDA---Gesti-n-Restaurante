package model;

import java.util.ArrayList;

public class Menu {

    private ArrayList<Item> items;
}
