package controller;

import model.Manager;
import model.Device;
import system.SystemException;
import system.SystemFacade;
import view.ManagerLoginView;

public class ManagerLoginController {

    private final SystemFacade system;
    private final ManagerLoginView view;
    private final Device activeDevice;

    public ManagerLoginController(SystemFacade system, Device device) {
        this.system = system;
        this.activeDevice = device;
        this.view = new ManagerLoginView(this);
    }

    public void handleLogin() {
        String username = view.getUsernameField();
        String password = view.getPasswordField();

        try {
            Manager manager = system.getManager(username, password);
            view.showMessage("Inicio de sesión exitoso.");
            view.close();
            new ManagerController(system, manager, activeDevice);
        } catch (SystemException e) {
            view.showMessage(e.getMessage());
        }
    }
}
