package controller;

import model.*;
import observer.Observer;
import system.SystemException;
import system.SystemFacade;
import view.ManagerView;

import java.util.List;

public class ManagerController implements Observer {

    private final SystemFacade system;
    private final Manager manager;
    private final Device activeDevice;
    private final ManagerView view;

    public ManagerController(SystemFacade system, Manager manager, Device device) {
        this.system = system;
        this.manager = manager;
        this.activeDevice = device;
        this.view = new ManagerView(this);
        system.addObserver(this);
        update();
    }

    public void handleTakeOrder(Order order) {
        handleAdvanceOrder(order);
    }

    public void handleReadyOrder(Order order) {
        handleAdvanceOrder(order);
    }

    public void handleDeliverOrder(Order order) {
        handleAdvanceOrder(order);
    }

    public void handleAdvanceOrder(Order order) {
        try {
            order.advanceState(manager);
            view.showMessage("Pedido actualizado correctamente.");
            system.notifyObservers();

        } catch (SystemException e) {
            view.showMessage(e.getMessage());
        }
    }

    @Override
    public void update() {
        List<Order> pending = system.getOrdersByUnitAndState(manager.getPU(), OrderState.NOT_CONFIRMED);
        List<Order> taken = system.getOrdersByManager(manager, OrderState.IN_PROGRESS, OrderState.READY);
        view.updatePendingList(pending);
        view.updateTakenList(taken);
    }
}
